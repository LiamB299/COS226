public class MemberOptions {
    public static int enqueuers = 4;
    public static int dequeuers = 4;
    public static int runs = 3;
}
