public class MemberOptions {
    public static int adders = 3;
    public static int removers = 3;
    public static int runs = 3;
}
