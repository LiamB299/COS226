public class Task {


    public Task(String taskName){
  
    }

    public void setNextTask(Task nextTask) {
 
    }

    public Task getNextTask() {
       
    }

    public String getTaskName() {
        
    }

}
