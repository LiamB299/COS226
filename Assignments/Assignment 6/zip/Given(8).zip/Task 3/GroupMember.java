public class GroupMember extends Thread{

   public GroupMember(BoundedQueueToDoList queue, boolean enqueue, String taskName){
       
    }

    public void run(){

    }
}
