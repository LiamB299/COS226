public class BoundedQueueToDoList {

    public BoundedQueueToDoList(int capacity, String[] tasks) {
        
    }

    public void enq(String taskName) {

    }

    public void deq() {

    }

    public void printList(){


    }

}