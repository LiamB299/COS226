public class LazyToDoList {

   LazyToDoList(String[] taskNames) {
       
    }

    public void addTask(String name) {
  
    }

    public void removeTask(String name){

       
    }

    public void printList(){


    }

}
