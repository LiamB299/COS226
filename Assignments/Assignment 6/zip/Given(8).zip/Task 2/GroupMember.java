public class GroupMember extends Thread {

    public GroupMember(LazyToDoList toDoList, boolean adder, String taskName){
        
    }

    public void run(){
        
    }
}
