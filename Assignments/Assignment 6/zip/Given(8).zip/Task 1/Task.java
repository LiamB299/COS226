import java.util.concurrent.locks.ReentrantLock;

public class Task {
   
    public Task(String taskName){
    }

    public void lock(){
    }

    public void unlock(){
    }

    public String getTaskName(){
    }

    public Task getNextTask(){
    }

    public void setNextTask(Task nextTask){

    }

}
