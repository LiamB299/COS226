import java.util.logging.Logger;

public class OptimisticToDoList {

   
    OptimisticToDoList(String[] taskNames) {
    	
    }

    public void addTask(String name) {
    	
    }

    public void removeTask(String name){
    	
	}

    public void printList(){

    }

    private boolean validate(Task predecessor, Task current) {
    	
    }
 }
