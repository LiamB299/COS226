
public class GroupMember extends Thread {


    public GroupMember(OptimisticToDoList list, Boolean adder, String taskName){
    }

    public void run(){

    }
}
