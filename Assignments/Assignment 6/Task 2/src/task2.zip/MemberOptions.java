public class MemberOptions {
    public static int adders = 4;
    public static int removers = 4;
    public static int runs = 3;
}
