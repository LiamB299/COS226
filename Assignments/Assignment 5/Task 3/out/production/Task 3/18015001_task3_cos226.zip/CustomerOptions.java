public class CustomerOptions {

    public static int customers = 6;

    public static int runs = 1;

    public static int capacity = 2;

}
