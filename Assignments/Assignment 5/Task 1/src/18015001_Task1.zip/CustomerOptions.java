public class CustomerOptions {
    static int customers = 3;

    static int runs = 3;

    static long wait = 10;
}
