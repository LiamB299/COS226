public class CustomerOptions {

    public static int writers = 3;

    public static int readers = 6;

    public static int runs = 3;

}
