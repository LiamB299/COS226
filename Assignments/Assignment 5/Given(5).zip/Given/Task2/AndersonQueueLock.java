// Practical 5
// Name and surname:
// Student number:

public class AndersonQueueLock extends AbstractLock {

    public AndersonQueueLock(int numThreads) {
        
    }

    public void lock() {
        
    }


    public void unlock() {
        
    }

}
