// Practical 5
// Name and surname:
// Student number:

public class TTASLock extends AbstractLock {
	
	public void lock() {
		
	}
	
 	public void unlock() {
 		
 	}

}
