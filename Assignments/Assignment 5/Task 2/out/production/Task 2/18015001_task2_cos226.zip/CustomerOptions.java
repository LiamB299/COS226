public class CustomerOptions {

    public static int customers = 8;

    public static int runs = 1;

}
