import java.util.logging.Level;
import java.util.logging.Logger;

public class StackConsensus extends ConsensusProtocol<Integer> {
    enum name {
        Alice,
        Bob
    }

    // implementing stack as enum/array for simplicity.
    // The order is LIFO, so the first (winner) will be at the bottom
    // of the stack
    enum stack {
        LOSE,
        WIN
    }

    private volatile int access;
    private volatile Integer[] prop_v;
    private static volatile Logger LOGGER = Logger.getLogger("global");

    private name []names = name.values();
    private stack []race = stack.values();

    public StackConsensus(int threadCount) {
        super(threadCount);
        access = 0;
        prop_v = new Integer[threadCount];
    }

    private void prop_value(Integer v) {
        prop_v[ThreadID.get()] = v;
    }

    public void propose(Integer value) {
        //LOGGER.info("ID: "+ThreadID.get());
        prop_value(value);
        String prop = names[ThreadID.get()]+" wants to watch the program for "+value+" minutes";
        LOGGER.info(prop);
    }

    private int win_lose() {
        if(access==0) {
            access = 1;
            return access-1;
        }
        else {
            access = 0;
            return 1- access;
        }

    }

    public void decide() {
        int ans = win_lose();
        int dec_len = ThreadID.get();
        if(race[ans] == stack.LOSE)
            dec_len = 1 - dec_len;

        String dec = names[ThreadID.get()]+" drew a "+race[ans]+" from the stack";
        LOGGER.fine(dec);
        String con = names[ThreadID.get()]+" decided on "+prop_v[dec_len]+" minutes";
        LOGGER.info(con);
    }


}
