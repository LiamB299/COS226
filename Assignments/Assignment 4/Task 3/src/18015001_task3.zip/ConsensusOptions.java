public class ConsensusOptions {

    static int threads = 5;

    static long delay =1000;

    static int runs = 1;


}
