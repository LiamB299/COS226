public class ConsensusOptions {

    static int threads = 9;

    static long delay =1000;

    static int runs = 3;


}
