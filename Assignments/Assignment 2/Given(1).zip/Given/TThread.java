//Practical assignment 2
//Student Number:
//Student Name:
class TThread extends Thread {
	
	Account account;
	
	TThread(Account acc) {
		account = acc;
	}

	public void run() {
		System.out.println("Thread running...");
	}
}