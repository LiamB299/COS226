//Practical assignment 2
//Student Number:
//Student Name:

import java.util.concurrent.locks.Lock;

class Account {

	float balance;
	Lock lock;

	Account(float amount, Lock mylock) {
		// @todo: COMPLETE THIS FUNCTION
	}

	boolean withdraw(float amount, String threadName) {
		boolean isSuccess = false;	// indicates if withdrawal transaction was successful

		// @todo: COMPLETE THIS FUNCTION

		return isSuccess;
	}

	void deposit(float amount, String threadName) {
		// @todo: COMPLETE THIS FUNCTION
	}

	float getBalance()
	{
		return balance;
	}

}
