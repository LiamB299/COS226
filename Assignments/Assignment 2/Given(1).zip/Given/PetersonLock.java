//Practical assignment 2
//Student Number:
//Student Name:
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;

class PetersonLock implements Lock {

	public PetersonLock() {
	}

	public void lock() {
		// @todo: COMPLETE THIS FUNCTION
	}

	public void unlock() {
		// @todo: COMPLETE THIS FUNCTION
	}

	// Any class implementing Lock must provide these methods
	public Condition newCondition() {
		throw new java.lang.UnsupportedOperationException();
	}

	public boolean tryLock(long time, TimeUnit unit)
			throws InterruptedException {
		throw new java.lang.UnsupportedOperationException();
	}

	public boolean tryLock() {
		throw new java.lang.UnsupportedOperationException();
	}

	public void lockInterruptibly() throws InterruptedException {
		throw new java.lang.UnsupportedOperationException();
	}
}
