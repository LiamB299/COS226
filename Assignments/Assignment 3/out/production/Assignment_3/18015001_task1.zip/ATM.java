import java.util.Random;
import java.util.logging.Logger;

import static java.lang.Thread.sleep;

public class ATM {
    volatile private static Logger LOGGER = Logger.getLogger("global");
    volatile private float balance;
    int nTh;
    volatile Random ran = new Random();
    volatile FilterLock myLock;

    public ATM(float amount, int numThreads) {
        balance = amount;
        nTh = numThreads;
        myLock = new FilterLock(numThreads);
    }

    public void sl(long time) {
        try {
            sleep(time);
        }
        catch (InterruptedException e) {}
    }

    public boolean withdraw(float amount, int threadID) {
        //long generatedLong = 1 + (long) (Math.random() * (150 - 1));
        //sl(generatedLong);
        //LOGGER.fine("Thread-"+threadID+" waiting to perform transaction");
        myLock.lock();
        try {
            if (balance < amount) {
                LOGGER.info("Thread-" + threadID + " withdrawal of R" + String.format("%.2f", amount) + " not possible, insufficient funds. R" + String.format("%.2f", balance) + " remaining");
                return false;
            }
            else {
                balance -= amount;
                LOGGER.info("Thread-"+threadID+" withdrawing R"+String.format("%.2f", amount)+" from ATM, R"+String.format("%.2f", balance)+" remaining");
                return true;
            }
        }
        finally {
            myLock.unlock();
        }
    }

    public void deposit(float amount, int threadID) {
        //long generatedLong = 1 + (long) (Math.random() * (300 - 1));
        //sl(generatedLong);
        //LOGGER.fine("Thread-"+threadID+" waiting to perform transaction");
        myLock.lock();
        try {
            balance += amount;
            LOGGER.info("Thread-"+threadID+" depositing R"+String.format("%.2f", amount)+" to ATM, R"+String.format("%.2f", balance)+" remaining");
        }
        finally {
            myLock.unlock();
        }
    }

    public float getATMBalance() {
        return balance;
    }
}
