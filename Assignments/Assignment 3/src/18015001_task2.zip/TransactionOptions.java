public class TransactionOptions {
    public static int lines = 3;

    public static int cardUsers = 4;

    public static long withdrawalSleepTime = 200;

    public static long depositSleepTime = 200;
}
